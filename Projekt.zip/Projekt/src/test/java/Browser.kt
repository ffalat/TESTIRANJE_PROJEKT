

sealed class Browser {
    object Chrome : Browser()
    object Firefox : Browser()
}